<?php
 
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "amn_kev");
define("DB_PASSWORD", "Kevcom2015");
define("DB_DATABASE", "amn_arosto");
?>